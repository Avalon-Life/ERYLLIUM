RPC Port: 34822
Network Port: 34821